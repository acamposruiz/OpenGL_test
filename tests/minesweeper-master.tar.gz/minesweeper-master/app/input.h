/*
 * File: input.h.
 * Created by: Alex.Braidwood.
 * Date: Feb 20, 2019.
 * Notice: Copyright (c) 2019 The Bat Forge. All Rights Reserved.
 */

#ifndef MINESWEEPER_INPUT_H
#define MINESWEEPER_INPUT_H

#endif //MINESWEEPER_INPUT_H
